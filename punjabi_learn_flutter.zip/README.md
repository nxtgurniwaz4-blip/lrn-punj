# Learn Punjabi (Flutter)
Files: pubspec.yaml, lib/main.dart, codemagic.yaml.
Codemagic generates the android/ and ios/ folders for you (flutter create .).
