import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const PunjabiApp());

// letter, name, sound hint
const List<List<String>> letters = [
  ['ੳ', 'oodaa', 'silent carrier for u, oo'],
  ['ਅ', 'aidaa', 'silent carrier for a'],
  ['ੲ', 'eedi', 'silent carrier for i, ee'],
  ['ਸ', 'sassa', 's as in sun'],
  ['ਹ', 'haha', 'h as in hat'],
  ['ਕ', 'kakka', 'k as in kite'],
  ['ਖ', 'khakha', 'kh, breathy k'],
  ['ਗ', 'gagga', 'g as in go'],
  ['ਘ', 'ghagga', 'gh, breathy g'],
  ['ਙ', 'ngangga', 'ng as in sing'],
  ['ਚ', 'chachcha', 'ch as in chair'],
  ['ਛ', 'chhachha', 'chh, breathy ch'],
  ['ਜ', 'jajja', 'j as in jam'],
  ['ਝ', 'jhajja', 'jh, breathy j'],
  ['ਞ', 'nyanya', 'ny as in canyon'],
  ['ਟ', 'ttaina', 't, tongue curled back'],
  ['ਠ', 'tthattha', 'th, tongue curled back'],
  ['ਡ', 'ddadda', 'd, tongue curled back'],
  ['ਢ', 'ddhadha', 'dh, tongue curled back'],
  ['ਣ', 'nanna', 'n, tongue curled back'],
  ['ਤ', 'tatta', 't, tongue on teeth'],
  ['ਥ', 'thattha', 'th, tongue on teeth'],
  ['ਦ', 'dadda', 'd, tongue on teeth'],
  ['ਧ', 'dhadha', 'dh, tongue on teeth'],
  ['ਨ', 'nanna', 'n as in net'],
  ['ਪ', 'pappa', 'p as in pen'],
  ['ਫ', 'phapha', 'ph, breathy p'],
  ['ਬ', 'babba', 'b as in bat'],
  ['ਭ', 'bhabba', 'bh, breathy b'],
  ['ਮ', 'mamma', 'm as in map'],
  ['ਯ', 'yayya', 'y as in yes'],
  ['ਰ', 'rarra', 'r, tapped'],
  ['ਲ', 'lalla', 'l as in lamp'],
  ['ਵ', 'vavva', 'v or w'],
  ['ੜ', 'rhara', 'r, tongue flicked back'],
];

// gurmukhi, romanized, english
const Map<String, List<List<String>>> words = {
  'Greetings': [
    ['ਸਤ ਸ੍ਰੀ ਅਕਾਲ', 'sat sri akal', 'Hello'],
    ['ਕਿਵੇਂ ਹੋ?', 'kiven ho?', 'How are you?'],
    ['ਮੈਂ ਠੀਕ ਹਾਂ', 'main theek haan', 'I am fine'],
    ['ਧੰਨਵਾਦ', 'dhannvaad', 'Thank you'],
    ['ਮਾਫ਼ ਕਰਨਾ', 'maaf karna', 'Sorry'],
    ['ਹਾਂ', 'haan', 'Yes'],
    ['ਨਹੀਂ', 'nahin', 'No'],
    ['ਪਾਣੀ', 'paani', 'Water'],
    ['ਰੋਟੀ', 'roti', 'Bread'],
  ],
  'Numbers': [
    ['ਇੱਕ', 'ikk', '1 (one)'],
    ['ਦੋ', 'do', '2 (two)'],
    ['ਤਿੰਨ', 'tinn', '3 (three)'],
    ['ਚਾਰ', 'chaar', '4 (four)'],
    ['ਪੰਜ', 'panj', '5 (five)'],
    ['ਛੇ', 'chhe', '6 (six)'],
    ['ਸੱਤ', 'satt', '7 (seven)'],
    ['ਅੱਠ', 'atth', '8 (eight)'],
    ['ਨੌਂ', 'nau', '9 (nine)'],
    ['ਦਸ', 'das', '10 (ten)'],
  ],
  'Family': [
    ['ਮਾਂ', 'maa', 'Mother'],
    ['ਪਿਤਾ', 'pita', 'Father'],
    ['ਭਰਾ', 'bhraa', 'Brother'],
    ['ਭੈਣ', 'bhain', 'Sister'],
    ['ਦਾਦਾ', 'daada', 'Paternal grandfather'],
    ['ਦਾਦੀ', 'daadi', 'Paternal grandmother'],
    ['ਨਾਨਾ', 'naana', 'Maternal grandfather'],
    ['ਨਾਨੀ', 'naani', 'Maternal grandmother'],
  ],
  'Colors': [
    ['ਲਾਲ', 'laal', 'Red'],
    ['ਨੀਲਾ', 'neela', 'Blue'],
    ['ਹਰਾ', 'hara', 'Green'],
    ['ਪੀਲਾ', 'peela', 'Yellow'],
    ['ਚਿੱਟਾ', 'chitta', 'White'],
    ['ਕਾਲਾ', 'kaala', 'Black'],
  ],
};

List<List<String>> get allWords => words.values.expand((e) => e).toList();

final FlutterTts _tts = FlutterTts();
bool? _hasPunjabi;

// How each letter is actually said aloud (its name), so the voice
// does not just guess a sound for a lone character.
const Map<String, String> letterSpeech = {
  'ੳ': 'ਊਡਾ', 'ਅ': 'ਐਡਾ', 'ੲ': 'ਈਡੀ', 'ਸ': 'ਸੱਸਾ', 'ਹ': 'ਹਾਹਾ',
  'ਕ': 'ਕੱਕਾ', 'ਖ': 'ਖੱਖਾ', 'ਗ': 'ਗੱਗਾ', 'ਘ': 'ਘੱਗਾ', 'ਙ': 'ਙੰਙਾ',
  'ਚ': 'ਚੱਚਾ', 'ਛ': 'ਛੱਛਾ', 'ਜ': 'ਜੱਜਾ', 'ਝ': 'ਝੱਝਾ', 'ਞ': 'ਞੰਞਾ',
  'ਟ': 'ਟੈਂਕਾ', 'ਠ': 'ਠੱਠਾ', 'ਡ': 'ਡੱਡਾ', 'ਢ': 'ਢੱਢਾ', 'ਣ': 'ਣਾਣਾ',
  'ਤ': 'ਤੱਤਾ', 'ਥ': 'ਥੱਥਾ', 'ਦ': 'ਦੱਦਾ', 'ਧ': 'ਧੱਧਾ', 'ਨ': 'ਨੱਨਾ',
  'ਪ': 'ਪੱਪਾ', 'ਫ': 'ਫੱਫਾ', 'ਬ': 'ਬੱਬਾ', 'ਭ': 'ਭੱਭਾ', 'ਮ': 'ਮੱਮਾ',
  'ਯ': 'ਯੱਯਾ', 'ਰ': 'ਰਾਰਾ', 'ਲ': 'ਲੱਲਾ', 'ਵ': 'ਵੱਵਾ', 'ੜ': 'ੜਾੜਾ',
};

// Gurmukhi and Devanagari share the same layout, so Hindi voices can
// read Punjabi once the text is converted.
String toDevanagari(String s) {
  final out = StringBuffer();
  for (final r in s.runes) {
    if (r == 0x0A70) {
      out.writeCharCode(0x0902); // tippi -> anusvara
    } else if (r == 0x0A71) {
      out.writeCharCode(0x094D); // addak -> doubles next consonant
    } else if ((r >= 0x0A01 && r <= 0x0A5E) || (r >= 0x0A66 && r <= 0x0A6F)) {
      out.writeCharCode(r - 0x100);
    } else {
      out.writeCharCode(r);
    }
  }
  return out.toString();
}

final AudioPlayer _player = AudioPlayer();
final Map<String, Uint8List> _audioCache = {};

// Google Cloud neural voice. The key is given at build time
// (--dart-define=TTS_KEY=...). Without a key this step is skipped.
const String _ttsKey = String.fromEnvironment('TTS_KEY');

Future<Uint8List?> _cloudAudio(String text) async {
  if (_ttsKey.isEmpty) return null;
  final res = await http
      .post(
        Uri.parse(
            'https://texttospeech.googleapis.com/v1/text:synthesize?key=$_ttsKey'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'input': {'text': text},
          'voice': {'languageCode': 'pa-IN', 'name': 'pa-IN-Wavenet-A'},
          'audioConfig': {'audioEncoding': 'MP3', 'speakingRate': 0.85},
        }),
      )
      .timeout(const Duration(seconds: 8));
  if (res.statusCode != 200) return null;
  return base64Decode(jsonDecode(res.body)['audioContent'] as String);
}

// Online voice: Google Cloud neural voice first, then the free
// Google Translate voice. Returns false if neither answers.
Future<bool> _speakOnline(String text) async {
  try {
    var bytes = _audioCache[text];
    if (bytes == null) {
      try {
        bytes = await _cloudAudio(text);
      } catch (_) {}
      if (bytes == null) {
        final uri = Uri.https('translate.google.com', '/translate_tts', {
          'ie': 'UTF-8',
          'q': text,
          'tl': 'pa',
          'client': 'tw-ob',
        });
        final res = await http.get(uri, headers: {
          'User-Agent':
              'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
        }).timeout(const Duration(seconds: 6));
        if (res.statusCode != 200 || res.bodyBytes.length < 500) return false;
        bytes = res.bodyBytes;
      }
      _audioCache[text] = bytes;
    }
    await _tts.stop();
    await _player.stop();
    await _player.play(BytesSource(bytes, mimeType: 'audio/mpeg'));
    return true;
  } catch (_) {
    return false;
  }
}

// ---- Your own voice recordings, bundled in assets/audio/ ----
// Name each file L01..L35 (letters) and W01..W33 (words), for example
// assets/audio/L01.m4a. Anything without a file uses the computer voice.
Map<String, String>? _ids;
Map<String, String> _idMap() {
  if (_ids != null) return _ids!;
  final m = <String, String>{};
  for (var i = 0; i < letters.length; i++) {
    m[letters[i][0]] = 'L${(i + 1).toString().padLeft(2, '0')}';
  }
  final aw = allWords;
  for (var i = 0; i < aw.length; i++) {
    m[aw[i][0]] = 'W${(i + 1).toString().padLeft(2, '0')}';
  }
  return _ids = m;
}

final Map<String, String> _bundled = {}; // id -> asset path

Future<void> loadBundledAudio() async {
  try {
    final manifest = await AssetManifest.loadFromAssetBundle(rootBundle);
    const exts = {'m4a', 'mp3', 'wav', 'aac', 'caf', 'ogg', 'mp4'};
    for (final key in manifest.listAssets()) {
      if (!key.startsWith('assets/audio/')) continue;
      final file = key.split('/').last;
      final dot = file.lastIndexOf('.');
      if (dot <= 0) continue;
      if (!exts.contains(file.substring(dot + 1).toLowerCase())) continue;
      _bundled[file.substring(0, dot).toUpperCase()] = key;
    }
  } catch (_) {}
}

Future<void> speak(String text) async {
  // Your own recording comes first.
  try {
    final id = _idMap()[text];
    final asset = id == null ? null : _bundled[id];
    if (asset != null) {
      await _tts.stop();
      await _player.stop();
      await _player.play(AssetSource(asset.substring('assets/'.length)));
      return;
    }
  } catch (_) {}
  final spoken = letterSpeech[text] ?? text;
  if (await _speakOnline(spoken)) return;
  // Offline fallback: the phone's own voice.
  try {
    if (_hasPunjabi == null) {
      final r = await _tts.isLanguageAvailable('pa-IN');
      _hasPunjabi = (r == true || r == 1);
    }
    await _tts.stop();
    await _tts.setSpeechRate(0.4);
    if (_hasPunjabi!) {
      await _tts.setLanguage('pa-IN');
      await _tts.speak(spoken);
    } else {
      await _tts.setLanguage('hi-IN');
      await _tts.speak(toDevanagari(spoken));
    }
  } catch (_) {}
}

class PunjabiApp extends StatelessWidget {
  const PunjabiApp({super.key});
  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFFD6336C);
    return MaterialApp(
      title: 'Learn Punjabi',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: seed, useMaterial3: true),
      darkTheme: ThemeData(
          colorSchemeSeed: seed,
          brightness: Brightness.dark,
          useMaterial3: true),
      home: const Home(),
    );
  }
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int tab = 0;
  Set<String> done = {};
  Map<String, int> best = {'letters': 0, 'words': 0};
  SharedPreferences? prefs;

  @override
  void initState() {
    super.initState();
    loadBundledAudio();
    SharedPreferences.getInstance().then((p) {
      prefs = p;
      setState(() {
        done = (p.getStringList('done') ?? []).toSet();
        best = {
          'letters': p.getInt('bestLetters') ?? 0,
          'words': p.getInt('bestWords') ?? 0,
        };
      });
    });
  }

  void toggle(String g) {
    setState(() => done.contains(g) ? done.remove(g) : done.add(g));
    prefs?.setStringList('done', done.toList());
  }

  void setBest(String mode, int score) {
    if (score > (best[mode] ?? 0)) {
      setState(() => best[mode] = score);
      prefs?.setInt(mode == 'letters' ? 'bestLetters' : 'bestWords', score);
    }
  }

  @override
  Widget build(BuildContext context) {
    final total = letters.length + allWords.length;
    final pages = [
      LettersTab(done: done, onToggle: toggle),
      WordsTab(done: done, onToggle: toggle),
      QuizTab(best: best, onBest: setBest),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('ਪੰਜਾਬੀ',
            style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(28),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
            child: Row(children: [
              Expanded(
                child: LinearProgressIndicator(
                  value: done.length / total,
                  minHeight: 8,
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              const SizedBox(width: 10),
              Text('${done.length}/$total learned'),
            ]),
          ),
        ),
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 700),
            child: pages[tab],
          ),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.abc), label: 'Letters'),
          NavigationDestination(icon: Icon(Icons.translate), label: 'Words'),
          NavigationDestination(icon: Icon(Icons.quiz), label: 'Quiz'),
        ],
      ),
    );
  }
}

class LettersTab extends StatefulWidget {
  final Set<String> done;
  final void Function(String) onToggle;
  const LettersTab({super.key, required this.done, required this.onToggle});
  @override
  State<LettersTab> createState() => _LettersTabState();
}

class _LettersTabState extends State<LettersTab> {
  int sel = 0;
  @override
  Widget build(BuildContext context) {
    final c = letters[sel];
    final cs = Theme.of(context).colorScheme;
    final known = widget.done.contains(c[0]);
    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(children: [
            Text(c[0],
                style: TextStyle(
                    fontSize: 88,
                    color: cs.primary,
                    fontWeight: FontWeight.w600)),
            Text(c[1], style: Theme.of(context).textTheme.titleLarge),
            Text(c[2], style: TextStyle(color: cs.onSurfaceVariant)),
            const SizedBox(height: 12),
            Wrap(spacing: 8, runSpacing: 8, children: [
              FilledButton.icon(
                  onPressed: () => speak(c[0]),
                  icon: const Icon(Icons.volume_up),
                  label: const Text('Hear it')),
              OutlinedButton.icon(
                  onPressed: () => widget.onToggle(c[0]),
                  icon: Icon(known
                      ? Icons.check_circle
                      : Icons.check_circle_outline),
                  label: Text(known ? 'Learned' : 'I know this')),
            ]),
          ]),
        ),
      ),
      const SizedBox(height: 12),
      GridView.extent(
        maxCrossAxisExtent: 96,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
        childAspectRatio: 0.95,
        children: [
          for (var i = 0; i < letters.length; i++)
            InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () {
                setState(() => sel = i);
                speak(letters[i][0]);
              },
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    width: 2,
                    color: i == sel
                        ? cs.primary
                        : widget.done.contains(letters[i][0])
                            ? Colors.green
                            : cs.outlineVariant,
                  ),
                ),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(letters[i][0],
                          style: const TextStyle(
                              fontSize: 30, fontWeight: FontWeight.w600)),
                      Text(letters[i][1],
                          style: TextStyle(
                              fontSize: 11, color: cs.onSurfaceVariant)),
                    ]),
              ),
            ),
        ],
      ),
    ]);
  }
}

class WordsTab extends StatefulWidget {
  final Set<String> done;
  final void Function(String) onToggle;
  const WordsTab({super.key, required this.done, required this.onToggle});
  @override
  State<WordsTab> createState() => _WordsTabState();
}

class _WordsTabState extends State<WordsTab> {
  String cat = 'Greetings';
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return ListView(padding: const EdgeInsets.all(16), children: [
      Wrap(spacing: 8, children: [
        for (final k in words.keys)
          ChoiceChip(
              label: Text(k),
              selected: cat == k,
              onSelected: (_) => setState(() => cat = k)),
      ]),
      const SizedBox(height: 8),
      for (final w in words[cat]!)
        Card(
          child: ListTile(
            isThreeLine: true,
            onTap: () => speak(w[0]),
            title: Text(w[0],
                style: TextStyle(
                    fontSize: 26,
                    color: cs.primary,
                    fontWeight: FontWeight.w600)),
            subtitle: Text('${w[1]}\n${w[2]}'),
            trailing: IconButton(
              tooltip: 'Mark learned',
              onPressed: () => widget.onToggle(w[0]),
              icon: Icon(
                widget.done.contains(w[0])
                    ? Icons.check_circle
                    : Icons.check_circle_outline,
                color: widget.done.contains(w[0]) ? Colors.green : null,
              ),
            ),
          ),
        ),
    ]);
  }
}

class _Q {
  final String gurmukhi;
  final List<String> opts;
  final String ans;
  _Q(this.gurmukhi, this.opts, this.ans);
}

class QuizTab extends StatefulWidget {
  final Map<String, int> best;
  final void Function(String, int) onBest;
  const QuizTab({super.key, required this.best, required this.onBest});
  @override
  State<QuizTab> createState() => _QuizTabState();
}

class _QuizTabState extends State<QuizTab> {
  String? mode;
  List<_Q> qs = [];
  int i = 0, score = 0;
  String? picked;

  void start(String m) {
    final pool = m == 'letters' ? letters : allWords;
    String lab(List<String> x) => m == 'letters' ? x[1] : x[2];
    final rnd = Random();
    final pick = ([...pool]..shuffle(rnd)).take(10).toList();
    qs = pick.map((c) {
      final wrong = ([...pool.where((x) => lab(x) != lab(c))]..shuffle(rnd))
          .take(3)
          .map(lab);
      final opts = [...wrong, lab(c)]..shuffle(rnd);
      return _Q(c[0], opts, lab(c));
    }).toList();
    setState(() {
      mode = m;
      i = 0;
      score = 0;
      picked = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    if (mode == null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('ਕੁਇਜ਼',
                style: TextStyle(
                    fontSize: 56,
                    color: cs.primary,
                    fontWeight: FontWeight.w800)),
            const Text('Ten questions. Match each Punjabi item to its meaning.',
                textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton(
                onPressed: () => start('letters'),
                child: const Text('Letter quiz')),
            const SizedBox(height: 8),
            FilledButton(
                onPressed: () => start('words'),
                child: const Text('Word quiz')),
            const SizedBox(height: 16),
            Text(
                'Best: letters ${widget.best['letters']}/10, words ${widget.best['words']}/10',
                style: TextStyle(color: cs.onSurfaceVariant)),
          ]),
        ),
      );
    }
    if (i >= qs.length) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('$score/10',
              style: const TextStyle(
                  fontSize: 64,
                  fontWeight: FontWeight.w800,
                  color: Colors.green)),
          Text(score >= 8
              ? 'Shabash! Great work.'
              : score >= 5
                  ? 'Good progress. Review the cards and try again.'
                  : 'Keep practising. Start with the Letters tab.'),
          const SizedBox(height: 16),
          FilledButton(
              onPressed: () => start(mode!), child: const Text('Play again')),
          TextButton(
              onPressed: () => setState(() => mode = null),
              child: const Text('Change quiz')),
        ]),
      );
    }
    final q = qs[i];
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Question ${i + 1} of 10, score $score',
          style: TextStyle(color: cs.onSurfaceVariant)),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(children: [
            Text(q.gurmukhi,
                style: TextStyle(
                    fontSize: 56,
                    color: cs.primary,
                    fontWeight: FontWeight.w600)),
            Text(mode == 'letters'
                ? 'What is this letter called?'
                : 'What does this mean?'),
            TextButton.icon(
                onPressed: () => speak(q.gurmukhi),
                icon: const Icon(Icons.volume_up),
                label: const Text('Hear it')),
          ]),
        ),
      ),
      for (final o in q.opts)
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: FilledButton.tonal(
            style: FilledButton.styleFrom(
              minimumSize: const Size.fromHeight(50),
              backgroundColor: picked == null
                  ? null
                  : o == q.ans
                      ? Colors.green
                      : o == picked
                          ? cs.error
                          : null,
              foregroundColor:
                  picked != null && (o == q.ans || o == picked)
                      ? Colors.white
                      : null,
            ),
            onPressed: () {
              if (picked != null) return;
              setState(() {
                picked = o;
                if (o == q.ans) score++;
              });
            },
            child: Text(o),
          ),
        ),
      if (picked != null)
        Padding(
          padding: const EdgeInsets.only(top: 16),
          child: FilledButton(
            onPressed: () {
              setState(() {
                i++;
                picked = null;
              });
              if (i >= qs.length) widget.onBest(mode!, score);
            },
            child: Text(i == 9 ? 'See score' : 'Next question'),
          ),
        ),
    ]);
  }
}
