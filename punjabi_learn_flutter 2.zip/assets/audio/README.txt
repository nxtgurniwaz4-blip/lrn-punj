Put your voice recordings here (or at the top level of the repo, the build moves them).
Name them L01..L35 for letters and W01..W33 for words, e.g. L01.m4a, W05.mp3.
See recording_list.txt for what to say in each one.
